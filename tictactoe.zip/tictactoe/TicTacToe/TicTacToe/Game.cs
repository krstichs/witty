﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Game : Form
    {
        public Game()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void catchError()
        {
            DialogResult dr = MessageBox.Show("Something went wrong. Try again or relaunch the application.");
            if (dr == DialogResult.OK) this.Close();
        }
        private void checkWinner()
        {
            if (haveWinner == false && turnCounter < 10)
            {
                try
                {
                    // Let's check for the --- in all 3 rows for X first and then for O
                    if ((A1.Text == A2.Text && A2.Text == A3.Text && A3.Text == "❌") || (B1.Text == B2.Text && B2.Text == B3.Text && B3.Text == "❌") || (C1.Text == C2.Text && C2.Text == C3.Text && C3.Text == "❌")) { haveWinner = true; winner = "X"; }
                    else if ((A1.Text == A2.Text && A2.Text == A3.Text && A3.Text == "🔘") || (B1.Text == B2.Text && B2.Text == B3.Text && B3.Text == "🔘") || (C1.Text == C2.Text && C2.Text == C3.Text && C3.Text == "🔘")) { haveWinner = true; winner = "O"; }
                    // Let's check for ||| in all 3 columns for X first and then for O
                    else if ((A1.Text == B1.Text && B1.Text == C1.Text && C1.Text == "❌") || (A2.Text == B2.Text && B2.Text == C2.Text && C2.Text == "❌") || (A3.Text == B3.Text && B3.Text == C3.Text && C3.Text == "❌")) { haveWinner = true; winner = "X"; }
                    else if ((A1.Text == B1.Text && B1.Text == C1.Text && C1.Text == "🔘") || (A2.Text == B2.Text && B2.Text == C2.Text && C2.Text == "🔘") || (A3.Text == B3.Text && B3.Text == C3.Text && C3.Text == "🔘")) { haveWinner = true; winner = "O"; }
                    // Let's check for / and \ diagonals - first for X and then for O
                    else if ((A1.Text == B2.Text && B2.Text == C3.Text && C3.Text == "❌") || (A3.Text == B2.Text && B2.Text == C1.Text && C1.Text == "❌")) { haveWinner = true; winner = "X"; }
                    else if ((A1.Text == B2.Text && B2.Text == C3.Text && C3.Text == "🔘") || (A3.Text == B2.Text && B2.Text == C1.Text && C1.Text == "🔘")) { haveWinner = true; winner = "O"; }
                    else if(turnCounter == 9) { haveWinner = true; winner = "D"; }
                    

                    if(haveWinner)
                    {
                        timer1.Stop();
                        announceWinner(winner);
                    }

                }
                catch
                {
                    catchError();
                }
            }
        }

        private void announceWinner(string winnerCode)
        {
            string message, title;
            switch(winnerCode)
            {
                case "X":
                    message = "Winner is player X!";
                    title = "Congrats!";
                    xNOWins++;
                    break;
                case "O":
                    message = "Winner is player O!";
                    title = "Congrats!";
                    oNOWins++;
                    break;
                default:
                    message = "Seems like there is no winner!\nTry beating each other again.";
                    title = "Draw";
                    break;
            }
            DialogResult dr = MessageBox.Show(message, title);
            if (dr == DialogResult.OK) NewGameLoad();
        }


        private void NewGameLoad()
        {
            arrayOfButtons = new Button[] { A1, A2, A3, B1, B2, B3, C1, C2, C3 };
            haveWinner = false;
            turnCounter = 0;
            lblXscore.Text = $"X: {xNOWins}";
            lblOscore.Text = $"O: {oNOWins}";
            emptyButtonText();
            timer1.Interval = 100;
            timer1.Start();
        }
        
        bool playerTurn = true; // this means that it is X's turn ---> false is O's turn
        bool haveWinner = false;
        string winner = "";
        int turnCounter = 0;
        int xNOWins = 0;
        int oNOWins = 0;
        private void buttonAssigned(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            try 
            {

                if(button.Text == string.Empty)
                {
                    if (playerTurn == true)
                    {
                        button.Text = "❌";
                        button.Font = new Font("Cambria", 48);
                    }
                    else if (playerTurn == false)
                    {
                        button.Text = "🔘";
                        button.Font = new Font("Cambria", 55);
                    }
                    playerTurn = !playerTurn;
                    turnCounter++;
                }
            }
            catch
            {
                catchError();
            }
        }

        private Button[] arrayOfButtons;
        private void Game_Load(object sender, EventArgs e)
        {
            NewGameLoad();
        }

        private void emptyButtonText()
        {
            foreach(Button but in arrayOfButtons)
            {
                but.Text = string.Empty;
            }
        }
        private void label3_Click(object sender, EventArgs e)
        {
            Manual manual = new Manual();
            manual.Show();
        }

        private void colorTurn()
        {
            if(playerTurn)
            {
                lblXscore.BackColor = Color.LimeGreen;
                lblXscore.ForeColor = Color.Black;
                lblOscore.BackColor = Color.Transparent;
                lblOscore.ForeColor = Color.White;
            } else
            {
                lblOscore.BackColor = Color.LimeGreen;
                lblOscore.ForeColor = Color.Black;
                lblXscore.BackColor = Color.Transparent;
                lblXscore.ForeColor = Color.White;
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            checkWinner();
            colorTurn();
        }
    }
}
